class WastePostDTO {
  DateTime date;
  double latitude;
  double longitude;
  String imageURL;
  int quantity;
}